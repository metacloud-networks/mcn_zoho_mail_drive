from setuptools import setup, find_packages

with open("requirements.txt") as f:
    install_requires = f.read().strip().split("\n")

setup(
    name="zoho_workspace_connector",
    version="1.0.0",
    description="Zoho Workspace Connector for ERPNext 16 — Zoho Mail & WorkDrive integration",
    author="Meta Cloud Networks Ltd",
    author_email="info@mcnets.co.uk",
    packages=find_packages(),
    zip_safe=False,
    include_package_data=True,
    install_requires=install_requires,
)
