"""
Zoho WorkDrive REST API Client
Covers: list files, upload, download, create folders, share links.
"""
import frappe
import requests
import io
from zoho_workspace_connector.oauth.token_manager import get_valid_access_token, get_settings


def _headers(content_type="application/json"):
    h = {"Authorization": f"Zoho-oauthtoken {get_valid_access_token()}"}
    if content_type:
        h["Content-Type"] = content_type
    return h


def _drive_base():
    return get_settings().get_api_base()["workdrive"]


def get_team_id() -> str:
    """Fetch the WorkDrive Team ID for the authenticated user."""
    r = requests.get(f"{_drive_base()}/users/me", headers=_headers(), timeout=15)
    r.raise_for_status()
    data = r.json()
    return data.get("data", {}).get("attributes", {}).get("default_team_id", "")


def list_files(folder_id: str = None) -> list:
    """List files/folders within a WorkDrive folder."""
    settings = get_settings()
    folder_id = folder_id or settings.default_folder_id
    if not folder_id:
        frappe.throw("No WorkDrive folder ID specified.")

    url = f"{_drive_base()}/files/{folder_id}/files"
    r = requests.get(url, headers=_headers(), timeout=15)
    r.raise_for_status()
    return r.json().get("data", [])


def upload_file(file_content: bytes, file_name: str, folder_id: str = None, mime_type: str = "application/octet-stream") -> dict:
    """
    Upload a file to Zoho WorkDrive.

    Args:
        file_content: raw bytes of the file
        file_name: filename including extension
        folder_id: target folder resource_id (defaults to settings)
        mime_type: MIME type of the file

    Returns:
        dict with file metadata including resource_id and permalink
    """
    settings = get_settings()
    folder_id = folder_id or settings.default_folder_id
    if not folder_id:
        frappe.throw("No WorkDrive folder ID configured.")

    url = f"{_drive_base()}/upload"
    headers = {"Authorization": f"Zoho-oauthtoken {get_valid_access_token()}"}

    files = {
        "content": (file_name, io.BytesIO(file_content), mime_type),
    }
    data = {
        "filename": file_name,
        "parent_id": folder_id,
        "override-name-exist": "true",
    }

    r = requests.post(url, headers=headers, files=files, data=data, timeout=60)
    r.raise_for_status()
    result = r.json()
    return result.get("data", {})


def download_file(file_id: str) -> bytes:
    """Download a file from WorkDrive by its resource_id."""
    url = f"{_drive_base()}/download/{file_id}"
    r = requests.get(url, headers=_headers(content_type=None), timeout=60)
    r.raise_for_status()
    return r.content


def create_folder(name: str, parent_id: str = None) -> dict:
    """Create a new folder in WorkDrive."""
    settings = get_settings()
    parent_id = parent_id or settings.default_folder_id

    url = f"{_drive_base()}/files"
    payload = {
        "data": {
            "attributes": {
                "name": name,
                "parent_id": parent_id,
                "type": "folder",
            },
            "type": "files",
        }
    }
    r = requests.post(url, json=payload, headers=_headers(), timeout=15)
    r.raise_for_status()
    return r.json().get("data", {})


def get_shareable_link(file_id: str, role: str = "viewer") -> str:
    """
    Generate a shareable link for a WorkDrive file.

    Args:
        file_id: resource_id of the file
        role: 'viewer' or 'editor'

    Returns:
        shareable URL string
    """
    url = f"{_drive_base()}/files/{file_id}/links"
    payload = {
        "data": {
            "attributes": {
                "role_id": "8" if role == "editor" else "7",  # 7=viewer, 8=editor
                "link_type": "1",  # 1 = anyone with link
                "expiry_date": "",
            },
            "type": "links",
        }
    }
    r = requests.post(url, json=payload, headers=_headers(), timeout=15)
    r.raise_for_status()
    return r.json().get("data", {}).get("attributes", {}).get("link", "")


def delete_file(file_id: str) -> bool:
    """Move a file to trash in WorkDrive."""
    url = f"{_drive_base()}/files/{file_id}"
    payload = {
        "data": {
            "attributes": {"status": "51"},  # 51 = trash
            "type": "files",
        }
    }
    r = requests.patch(url, json=payload, headers=_headers(), timeout=15)
    return r.ok
