"""
Post-install hooks for Zoho Workspace Connector.
Creates custom fields required for mail sync deduplication.
"""
import frappe


def after_install():
    _create_custom_fields()
    frappe.db.commit()
    print("Zoho Workspace Connector installed successfully.")


def _create_custom_fields():
    """Add zoho_message_id to Communication doctype for sync deduplication."""
    if not frappe.db.exists("Custom Field", "Communication-zoho_message_id"):
        frappe.get_doc({
            "doctype": "Custom Field",
            "dt": "Communication",
            "fieldname": "zoho_message_id",
            "fieldtype": "Data",
            "label": "Zoho Message ID",
            "read_only": 1,
            "hidden": 1,
            "no_copy": 1,
            "in_standard_filter": 0,
        }).insert(ignore_permissions=True)
        print("Custom field Communication.zoho_message_id created.")
    else:
        print("Custom field already exists — skipped.")
