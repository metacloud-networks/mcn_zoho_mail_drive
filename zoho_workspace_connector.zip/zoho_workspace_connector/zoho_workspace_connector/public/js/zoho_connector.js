/**
 * Zoho Workspace Connector — ERPNext Frontend Helpers
 * Adds "Connect Zoho" button on Zoho Workspace Settings form.
 */
frappe.ui.form.on("Zoho Workspace Settings", {
    refresh: function(frm) {
        // Connect button
        frm.add_custom_button(__("Authorize Zoho"), function() {
            frappe.call({
                method: "zoho_workspace_connector.api.zoho_api.get_auth_url",
                callback: function(r) {
                    if (r.message) {
                        window.open(r.message, "_blank", "width=600,height=700");
                        frappe.msgprint(__("A Zoho authorization window has opened. Complete the login there, then return here and refresh."));
                    }
                }
            });
        }, __("Zoho Actions"));

        // Test connection button
        frm.add_custom_button(__("Test Connection"), function() {
            frappe.call({
                method: "zoho_workspace_connector.api.zoho_api.test_connection",
                callback: function(r) {
                    if (r.message && r.message.status === "success") {
                        frappe.msgprint({
                            title: __("Connection OK"),
                            message: __("Connected! Zoho Mail Account ID: ") + r.message.account_id,
                            indicator: "green"
                        });
                    } else {
                        frappe.msgprint({
                            title: __("Connection Failed"),
                            message: r.message ? r.message.message : __("Unknown error"),
                            indicator: "red"
                        });
                    }
                }
            });
        }, __("Zoho Actions"));

        // Manual sync button
        frm.add_custom_button(__("Sync Inbox Now"), function() {
            frappe.call({
                method: "zoho_workspace_connector.api.zoho_api.sync_now",
                callback: function(r) {
                    frappe.show_alert({ message: __("Inbox sync complete"), indicator: "green" });
                    frm.reload_doc();
                }
            });
        }, __("Zoho Actions"));

        // Status indicator
        let status = frm.doc.connection_status || "Not Connected";
        let color = status === "Connected" ? "green" : "red";
        frm.dashboard.set_headline(
            `<span class="indicator ${color}"></span> ${status}`
        );
    }
});
