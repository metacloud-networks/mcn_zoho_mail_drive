"""
Zoho Mail REST API Client
Covers: send email, list folders, fetch messages, get account info.
"""
import frappe
import requests
from zoho_workspace_connector.oauth.token_manager import get_valid_access_token, get_settings


def _headers():
    return {
        "Authorization": f"Zoho-oauthtoken {get_valid_access_token()}",
        "Content-Type": "application/json",
    }


def _mail_base():
    return get_settings().get_api_base()["mail"]


def get_account_id() -> str:
    """Fetch the primary Zoho Mail account ID for the authenticated user."""
    r = requests.get(f"{_mail_base()}/accounts", headers=_headers(), timeout=15)
    r.raise_for_status()
    data = r.json()
    accounts = data.get("data", [])
    if not accounts:
        frappe.throw("No Zoho Mail accounts found for this OAuth token.")
    return accounts[0].get("accountId", "")


def send_email(to: list, subject: str, body: str, cc: list = None, html: bool = True, attachments: list = None):
    """
    Send an email via Zoho Mail API.

    Args:
        to: list of recipient email addresses
        subject: email subject
        body: email body (HTML or plain text)
        cc: list of CC addresses
        html: True = HTML body, False = plain text
        attachments: list of {"name": str, "content": base64_str, "mime": str}
    """
    settings = get_settings()
    account_id = settings.zoho_account_id or get_account_id()

    payload = {
        "fromAddress": settings.mail_from_address,
        "toAddress": ",".join(to),
        "subject": subject,
        "content": body,
        "mailFormat": "html" if html else "plaintext",
        "askReceipt": "no",
    }

    if cc:
        payload["ccAddress"] = ",".join(cc)

    if attachments:
        # Upload attachments first, get upload IDs
        upload_ids = []
        for att in attachments:
            uid = _upload_attachment(account_id, att)
            if uid:
                upload_ids.append(uid)
        if upload_ids:
            payload["attachments"] = [{"attachmentId": uid} for uid in upload_ids]

    url = f"{_mail_base()}/accounts/{account_id}/messages"
    r = requests.post(url, json=payload, headers=_headers(), timeout=20)
    r.raise_for_status()
    return r.json()


def _upload_attachment(account_id: str, attachment: dict) -> str:
    """Upload a base64 attachment and return its upload ID."""
    import base64, io
    url = f"{_mail_base()}/accounts/{account_id}/messages/attachments"
    content = base64.b64decode(attachment["content"])
    files = {"attach": (attachment["name"], io.BytesIO(content), attachment.get("mime", "application/octet-stream"))}
    headers = {"Authorization": f"Zoho-oauthtoken {get_valid_access_token()}"}
    r = requests.post(url, files=files, headers=headers, timeout=30)
    if r.ok:
        return r.json().get("data", {}).get("attachmentId", "")
    return ""


def list_folders(account_id: str = None) -> list:
    """List all folders for the Zoho Mail account."""
    settings = get_settings()
    account_id = account_id or settings.zoho_account_id
    r = requests.get(f"{_mail_base()}/accounts/{account_id}/folders", headers=_headers(), timeout=15)
    r.raise_for_status()
    return r.json().get("data", [])


def list_messages(folder_id: str, account_id: str = None, limit: int = 50, start: int = 0) -> list:
    """Fetch messages from a folder."""
    settings = get_settings()
    account_id = account_id or settings.zoho_account_id
    params = {"limit": limit, "start": start}
    url = f"{_mail_base()}/accounts/{account_id}/folders/{folder_id}/messages/view"
    r = requests.get(url, headers=_headers(), params=params, timeout=15)
    r.raise_for_status()
    return r.json().get("data", [])


def get_message(message_id: str, account_id: str = None) -> dict:
    """Get a full message including body."""
    settings = get_settings()
    account_id = account_id or settings.zoho_account_id
    url = f"{_mail_base()}/accounts/{account_id}/folders/message"
    params = {"messageId": message_id}
    r = requests.get(url, headers=_headers(), params=params, timeout=15)
    r.raise_for_status()
    return r.json().get("data", {})


def search_messages(query: str, account_id: str = None) -> list:
    """Search Zoho Mail messages."""
    settings = get_settings()
    account_id = account_id or settings.zoho_account_id
    params = {"searchKey": query, "limit": 50}
    url = f"{_mail_base()}/accounts/{account_id}/messages/search"
    r = requests.get(url, headers=_headers(), params=params, timeout=15)
    r.raise_for_status()
    return r.json().get("data", [])
