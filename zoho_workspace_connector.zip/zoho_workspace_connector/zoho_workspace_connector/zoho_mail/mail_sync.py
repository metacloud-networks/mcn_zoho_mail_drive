"""
Zoho Mail → ERPNext Communication Sync
Pulls inbox messages and creates/updates Communication docs in ERPNext.
"""
import frappe
from zoho_workspace_connector.zoho_mail.mail_client import list_folders, list_messages, get_message
from zoho_workspace_connector.oauth.token_manager import get_settings


def sync_inbox():
    """Scheduled daily task: sync Zoho inbox to ERPNext Communications."""
    settings = get_settings()
    if not settings.enable_zoho_mail or not settings.sync_inbox:
        return

    try:
        folders = list_folders()
        inbox = next((f for f in folders if f.get("folderName", "").lower() == "inbox"), None)
        if not inbox:
            frappe.log_error("Zoho inbox folder not found", "Zoho Mail Sync")
            return

        messages = list_messages(inbox["folderId"], limit=50)
        for msg in messages:
            _upsert_communication(msg)

        settings.last_synced = frappe.utils.now()
        settings.save(ignore_permissions=True)
        frappe.db.commit()

    except Exception as e:
        frappe.log_error(str(e), "Zoho Mail Sync Error")


def _upsert_communication(msg: dict):
    """Create a Communication doc from a Zoho mail message if it doesn't exist."""
    message_id = msg.get("messageId")
    if not message_id:
        return

    existing = frappe.db.get_value(
        "Communication", {"zoho_message_id": message_id}, "name"
    )
    if existing:
        return  # Already synced

    full = get_message(message_id)

    comm = frappe.new_doc("Communication")
    comm.communication_type = "Communication"
    comm.communication_medium = "Email"
    comm.sent_or_received = "Received"
    comm.subject = full.get("subject", "(No Subject)")
    comm.sender = full.get("fromAddress", "")
    comm.recipients = full.get("toAddress", "")
    comm.content = full.get("htmlContent") or full.get("content", "")
    comm.send_email = 0

    # Store Zoho message ID for deduplication (custom field needed — see install.py)
    comm.zoho_message_id = message_id

    try:
        comm.insert(ignore_permissions=True)
        frappe.db.commit()
    except Exception as e:
        frappe.log_error(str(e), f"Zoho Sync: Failed to insert message {message_id}")


def on_communication_insert(doc, method):
    """
    Hook: when an ERPNext Communication is created with sent_or_received=Sent,
    optionally route it through Zoho Mail instead of the default email service.
    """
    settings = get_settings()
    if not settings.enable_zoho_mail:
        return
    if doc.sent_or_received != "Sent" or doc.send_email != 1:
        return

    try:
        from zoho_workspace_connector.zoho_mail.mail_client import send_email
        send_email(
            to=[doc.recipients] if isinstance(doc.recipients, str) else doc.recipients,
            subject=doc.subject or "(No Subject)",
            body=doc.content or "",
            cc=[doc.cc] if doc.cc else None,
        )
    except Exception as e:
        frappe.log_error(str(e), "Zoho Mail: Send via Communication hook failed")
