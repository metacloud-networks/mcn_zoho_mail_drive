import frappe
from frappe.model.document import Document


class ZohoWorkspaceSettings(Document):
    def validate(self):
        if self.redirect_uri and not self.redirect_uri.startswith("https://"):
            frappe.msgprint(
                "Warning: Redirect URI should use HTTPS for production OAuth flows.",
                indicator="orange"
            )

    def get_api_base(self):
        dc_map = {
            "COM (.com)": "com",
            "EU (.eu)": "eu",
            "IN (.in)": "in",
            "AU (.com.au)": "com.au",
            "JP (.jp)": "jp",
        }
        dc = dc_map.get(self.data_center, "com")
        return {
            "accounts": f"https://accounts.zoho.{dc}",
            "mail": f"https://mail.zoho.{dc}/api",
            "workdrive": f"https://workdrive.zoho.{dc}/api/v1",
        }
