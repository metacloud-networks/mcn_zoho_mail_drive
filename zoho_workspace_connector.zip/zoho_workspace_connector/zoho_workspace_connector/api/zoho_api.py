"""
Whitelisted Frappe API endpoints for Zoho Workspace Connector.
Called from ERPNext frontend or external integrations.
"""
import frappe
from frappe import _


# ─── OAuth ────────────────────────────────────────────────────────────────────

@frappe.whitelist()
def get_auth_url():
    """Return the Zoho OAuth authorization URL for admin to open."""
    from zoho_workspace_connector.oauth.token_manager import get_authorization_url
    frappe.only_for("System Manager")
    return get_authorization_url()


@frappe.whitelist(allow_guest=True)
def oauth_callback(code: str = None, error: str = None, state: str = None):
    """
    OAuth callback endpoint — Zoho redirects here after authorization.
    Route: /api/method/zoho_workspace_connector.api.zoho_api.oauth_callback
    """
    if error:
        frappe.log_error(f"Zoho OAuth error: {error}", "Zoho OAuth Callback")
        return {"status": "error", "message": error}

    if not code:
        return {"status": "error", "message": "No authorization code received."}

    from zoho_workspace_connector.oauth.token_manager import exchange_code_for_tokens
    try:
        exchange_code_for_tokens(code)
        return {"status": "success", "message": "Zoho connected successfully."}
    except Exception as e:
        frappe.log_error(str(e), "Zoho OAuth Exchange Failed")
        return {"status": "error", "message": str(e)}


@frappe.whitelist()
def test_connection():
    """Test the current Zoho connection by fetching account info."""
    frappe.only_for("System Manager")
    try:
        from zoho_workspace_connector.zoho_mail.mail_client import get_account_id
        account_id = get_account_id()
        return {"status": "success", "account_id": account_id}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ─── Mail ─────────────────────────────────────────────────────────────────────

@frappe.whitelist()
def send_mail(to, subject, body, cc=None, html=True):
    """Send an email via Zoho Mail."""
    from zoho_workspace_connector.zoho_mail.mail_client import send_email
    to_list = [to] if isinstance(to, str) else to
    cc_list = [cc] if isinstance(cc, str) and cc else (cc or [])
    return send_email(to=to_list, subject=subject, body=body, cc=cc_list, html=bool(html))


@frappe.whitelist()
def get_inbox(limit=50):
    """Fetch inbox messages from Zoho Mail."""
    from zoho_workspace_connector.zoho_mail.mail_client import list_folders, list_messages
    folders = list_folders()
    inbox = next((f for f in folders if f.get("folderName", "").lower() == "inbox"), None)
    if not inbox:
        return []
    return list_messages(inbox["folderId"], limit=int(limit))


@frappe.whitelist()
def search_mail(query):
    """Search Zoho Mail messages."""
    from zoho_workspace_connector.zoho_mail.mail_client import search_messages
    return search_messages(query)


@frappe.whitelist()
def sync_now():
    """Manually trigger inbox sync."""
    frappe.only_for("System Manager")
    from zoho_workspace_connector.zoho_mail.mail_sync import sync_inbox
    sync_inbox()
    return {"status": "success", "message": "Inbox sync complete."}


# ─── WorkDrive ────────────────────────────────────────────────────────────────

@frappe.whitelist()
def list_drive_files(folder_id=None):
    """List files in a WorkDrive folder."""
    from zoho_workspace_connector.zoho_drive.drive_client import list_files
    return list_files(folder_id)


@frappe.whitelist()
def upload_to_drive(file_name, file_content_b64, folder_id=None, mime_type="application/octet-stream"):
    """Upload a base64-encoded file to WorkDrive."""
    import base64
    from zoho_workspace_connector.zoho_drive.drive_client import upload_file
    content = base64.b64decode(file_content_b64)
    return upload_file(content, file_name, folder_id, mime_type)


@frappe.whitelist()
def get_drive_share_link(file_id, role="viewer"):
    """Get a shareable link for a WorkDrive file."""
    from zoho_workspace_connector.zoho_drive.drive_client import get_shareable_link
    return get_shareable_link(file_id, role)


@frappe.whitelist()
def create_drive_folder(name, parent_id=None):
    """Create a folder in WorkDrive."""
    from zoho_workspace_connector.zoho_drive.drive_client import create_folder
    return create_folder(name, parent_id)
