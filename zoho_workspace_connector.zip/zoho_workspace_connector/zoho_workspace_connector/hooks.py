app_name = "zoho_workspace_connector"
app_title = "Zoho Workspace Connector"
app_publisher = "Meta Cloud Networks Ltd"
app_description = "Connects ERPNext 16 to Zoho Mail and Zoho WorkDrive via REST API"
app_email = "info@mcnets.co.uk"
app_license = "MIT"
app_version = "1.0.0"

# Doctypes
fixtures = []

# Website
app_include_css = ["/assets/zoho_workspace_connector/css/zoho_connector.css"]
app_include_js = ["/assets/zoho_workspace_connector/js/zoho_connector.js"]

# OAuth callback route
website_route_rules = [
    {"from_route": "/zoho/oauth/callback", "to_route": "zoho_oauth_callback"},
]

# Scheduled tasks
scheduler_events = {
    "hourly": [
        "zoho_workspace_connector.oauth.token_manager.refresh_token_if_expiring"
    ],
    "daily": [
        "zoho_workspace_connector.zoho_mail.mail_sync.sync_inbox"
    ],
}

# Email override (optional — routes ERPNext outbound through Zoho Mail)
# email_append_to = ["Communication"]

override_whitelisted_methods = {}

doc_events = {
    "Communication": {
        "after_insert": "zoho_workspace_connector.zoho_mail.mail_sync.on_communication_insert"
    }
}
