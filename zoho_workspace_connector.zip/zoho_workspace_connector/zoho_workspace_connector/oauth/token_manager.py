"""
Zoho OAuth 2.0 Token Manager
Handles authorization URL generation, token exchange, and auto-refresh.
"""
import frappe
import requests
from datetime import datetime, timedelta


def get_settings():
    return frappe.get_single("Zoho Workspace Settings")


def get_authorization_url():
    """Generate the Zoho OAuth 2.0 authorization URL."""
    settings = get_settings()
    base = settings.get_api_base()["accounts"]

    scopes = [
        # Mail scopes
        "ZohoMail.accounts.READ",
        "ZohoMail.messages.ALL",
        "ZohoMail.folders.ALL",
        # WorkDrive scopes
        "WorkDrive.files.ALL",
        "WorkDrive.team.READ",
        "WorkDrive.workspace.READ",
    ]

    params = {
        "scope": ",".join(scopes),
        "client_id": settings.client_id,
        "response_type": "code",
        "redirect_uri": settings.redirect_uri,
        "access_type": "offline",  # ensures refresh_token is issued
        "prompt": "consent",
    }

    query = "&".join(f"{k}={v}" for k, v in params.items())
    return f"{base}/oauth/v2/auth?{query}"


def exchange_code_for_tokens(auth_code: str):
    """Exchange authorization code for access + refresh tokens."""
    settings = get_settings()
    base = settings.get_api_base()["accounts"]

    response = requests.post(
        f"{base}/oauth/v2/token",
        data={
            "code": auth_code,
            "client_id": settings.client_id,
            "client_secret": settings.get_password("client_secret"),
            "redirect_uri": settings.redirect_uri,
            "grant_type": "authorization_code",
        },
        timeout=15,
    )
    data = response.json()

    if "error" in data:
        frappe.throw(f"Zoho OAuth error: {data['error']}")

    _save_tokens(data, settings)
    _auto_populate_ids(settings)
    return data


def refresh_access_token():
    """Use the refresh token to obtain a new access token."""
    settings = get_settings()
    base = settings.get_api_base()["accounts"]

    refresh_token = settings.get_password("refresh_token")
    if not refresh_token:
        frappe.throw("No refresh token stored. Please re-authorise Zoho.")

    response = requests.post(
        f"{base}/oauth/v2/token",
        data={
            "refresh_token": refresh_token,
            "client_id": settings.client_id,
            "client_secret": settings.get_password("client_secret"),
            "grant_type": "refresh_token",
        },
        timeout=15,
    )
    data = response.json()

    if "error" in data:
        frappe.log_error(f"Zoho token refresh failed: {data}", "Zoho Connector")
        frappe.throw(f"Token refresh failed: {data.get('error')}")

    _save_tokens(data, settings)
    return data.get("access_token")


def get_valid_access_token():
    """Return a valid access token, refreshing if within 5 minutes of expiry."""
    settings = get_settings()
    expiry = settings.token_expiry

    if expiry:
        expiry_dt = frappe.utils.get_datetime(expiry)
        if datetime.now() < expiry_dt - timedelta(minutes=5):
            return settings.get_password("access_token")

    return refresh_access_token()


def refresh_token_if_expiring():
    """Scheduled task: proactively refresh token if expiring within the hour."""
    settings = get_settings()
    if not settings.refresh_token:
        return

    expiry = settings.token_expiry
    if expiry:
        expiry_dt = frappe.utils.get_datetime(expiry)
        if datetime.now() > expiry_dt - timedelta(minutes=60):
            refresh_access_token()
            frappe.logger().info("Zoho: Access token proactively refreshed.")


def _save_tokens(data: dict, settings=None):
    if not settings:
        settings = get_settings()

    expires_in = int(data.get("expires_in", 3600))
    expiry = datetime.now() + timedelta(seconds=expires_in)

    settings.access_token = data["access_token"]
    if data.get("refresh_token"):
        settings.refresh_token = data["refresh_token"]
    settings.token_expiry = expiry.strftime("%Y-%m-%d %H:%M:%S")
    settings.connection_status = "Connected"
    settings.save(ignore_permissions=True)
    frappe.db.commit()


def _auto_populate_ids(settings):
    """Fetch and store account/team IDs after initial auth."""
    try:
        from zoho_workspace_connector.zoho_mail.mail_client import get_account_id
        from zoho_workspace_connector.zoho_drive.drive_client import get_team_id

        if settings.enable_zoho_mail and not settings.zoho_account_id:
            settings.zoho_account_id = get_account_id()

        if settings.enable_zoho_drive and not settings.workdrive_team_id:
            settings.workdrive_team_id = get_team_id()

        settings.save(ignore_permissions=True)
        frappe.db.commit()
    except Exception as e:
        frappe.log_error(str(e), "Zoho: Auto-populate IDs failed")
